/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;


import java.util.ResourceBundle;


import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;

import javafx.scene.control.Button;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Popup;
import model.*;
import model.Battle;


import javafx.scene.Scene;
import javafx.stage.Stage;
/**
 *
 * @author golfier
 */
public class controllerDeWorldGame implements Initializable {


    private static Game game = Game.getInstance();
    private static Battle bataille = Battle.getInstance();
    Player current_player;
    List<Player> players;
    //Mission mission = Mission.getInstance();

    @FXML
    ImageView imageView;

    @FXML
    Image image;

    @FXML
    Button btn_NextTurn;

    @FXML
    AnchorPane GameAnchor;

    @FXML
    AnchorPane imagePane;

    @FXML
    Label lb_NamePlayer;
    @FXML
    Label lb_Mission;
    @FXML
    Label lb_nb_unit;
    @FXML
    Label lb_nb_cannons;
    @FXML
    Label lb_nb_soldiers;
    @FXML
    Label lb_nb_horseRiders;

    @FXML
    Label lb_nb_Tanks;

    @FXML
    Label lb_nb_Planes
            ;
    @FXML
    ToggleGroup tGroup;

    @FXML
    ToggleGroup unitGroup;

    @FXML
    ToggleButton btn_attack;

    @FXML
    ToggleButton btn_renfort;

    @FXML
    ToggleButton btn_deplacement;

    @FXML
    ToggleButton tgb_Cannon;

    @FXML
    ToggleButton tgb_Soldier;

    @FXML
    ToggleButton tgb_HorseRider;

    @FXML
    ToggleButton tgTanks;

    @FXML
    ToggleButton tgPlanes;
    @FXML
    Button exitButton;
    @FXML
    Button returnMainMenuButton;
    @FXML
    Button adjustButton;
    @FXML
    Button howToPlayButton;
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        image = new Image("/resources/image_fixed2.png");
        imageView.setImage(image);
        players = game.getPlayerList();

        game.setTerritoryList(ImageProcessor.imageProcess(SwingFXUtils.fromFXImage(image, null)));

        imageView.setImage(ImageProcessor.colorTerritoryInitialization(imageView.getImage(), game.getPlayerList(), game.getTerritoryList()));

        //Player
        current_player = game.getPlayerList().get(0);
        lb_NamePlayer.setText(current_player.getName());
        lb_NamePlayer.setTextFill(javafx.scene.paint.Color.rgb(current_player.getColor().getRed(), current_player.getColor().getGreen(), current_player.getColor().getBlue(), current_player.getColor().getAlpha() / 255.0));



        // Unit

        lb_nb_unit.setText("" +current_player.getTroopsToDistribute());
        lb_nb_cannons.setText("0");
        lb_nb_soldiers.setText("0");
        lb_nb_horseRiders.setText("0");
        lb_nb_Tanks.setText("0");
        lb_nb_Planes.setText("0");

        tGroup.selectToggle(btn_renfort);
        unitGroup.selectToggle(tgb_Soldier);

        game.setState(GameStage.REINFORCEMENT);
        btn_renfort.setSelected(true);
        game.setSelectedUnitType(TroopType.SOLDIER);
        tgb_Soldier.setSelected(true);

        btn_attack.setDisable(true);
        btn_deplacement.setDisable(true);

        btn_renfort.selectedProperty().addListener((p, ov, nv) -> {
            game.setState(GameStage.REINFORCEMENT);
            lb_nb_unit.setText("" +current_player.getTroopsToDistribute());
            game.setSelectedTerritory1(null);
            game.setSelectedTerritory2(null);
        });
        btn_attack.selectedProperty().addListener((p, ov, nv) -> {
                    game.setState(GameStage.ATTACK);
                    game.setSelectedTerritory1(null);
                    game.setSelectedTerritory2(null);
                    btn_deplacement.setDisable(true);
                }
        );
        btn_deplacement.selectedProperty().addListener((p, ov, nv) -> {
                    game.setState(GameStage.DEPLACEMENT);
                    game.setSelectedTerritory1(null);
                    game.setSelectedTerritory2(null);
                }
        );

        tgb_Cannon.selectedProperty().addListener((p, ov, nv) -> {
                    game.setSelectedUnitType(TroopType.CANNON);
                }
        );
        tgb_Soldier.selectedProperty().addListener((p, ov, nv) -> {
            game.setSelectedUnitType(TroopType.SOLDIER);
        });

        tgb_HorseRider.selectedProperty().addListener((p, ov, nv) -> {
            game.setSelectedUnitType(TroopType.HORSE_RIDER);
        });

        tgPlanes.selectedProperty().addListener((p, ov, nv) -> {
            game.setSelectedUnitType(TroopType.PLANE);
        });

        tgTanks.selectedProperty().addListener((p, ov, nv) -> {
            game.setSelectedUnitType(TroopType.TANK);
        });

        for (Node node : GameAnchor.getChildren()){
            if (node instanceof Label){
                ((Label)node).setText("0");
            }
        }

        game.initTerritory();
        lb_nb_unit.setText(""+current_player.getTroopsToDistribute());
        update_Territory_Labels();
    }


    @FXML
    private void imagePaneMouseClicked(MouseEvent event) throws IOException{
        Territory terr = game.tellTerritory((int) event.getX(), (int) event.getY());

        if (terr != null){
            setSelectedTerritory(terr);
            update_Counters(terr);
            switch(game.getState().toString()){
                case "ATTACK":
                    if (game.getSelectedTerritory1() != null && game.getSelectedTerritory2() != null){
                        if (game.getSelectedTerritory1().terrAdjacent.contains(game.getSelectedTerritory2().name)){
                            if (game.getSelectedTerritory1().player.equals(current_player) && !game.getSelectedTerritory2().player.equals(current_player)){
                                bataille.attackBetweenTerritory(game.getSelectedTerritory1(), game.getSelectedTerritory2());
                                update_Map(game.getSelectedTerritory1());
                                update_Map(game.getSelectedTerritory2());
                                update_Territory_Labels();
                            }
                            game.setSelectedTerritory1(null);
                            game.setSelectedTerritory2(null);
                        }
                        else{
                            System.out.println("Non Adjacent territory");
                        }
                    }

                    break;
                case "REINFORCEMENT":
                    if (game.getSelectedTerritory1() != null){
                        if (terr.player.equals(current_player)){
                            Troop unitToDispatch = new Troop(game.getSelectedUnitType());
                            if(current_player.getTroopsToDistribute() >= unitToDispatch.getCost()){
                                terr.getTroopList().add(unitToDispatch);
                                update_Territory_Labels();
                                current_player.setTroopsToDistribute(current_player.getTroopsToDistribute() - unitToDispatch.getCost());
                                update_Counters(terr);
                                if (current_player.getTroopsToDistribute() < 1){
                                    btn_renfort.setDisable(true);
                                    btn_attack.setDisable(false);
                                    btn_deplacement.setDisable(false);
                                }
                            }
                        }
                    }
                    break;
                case "DEPLACEMENT":
                    if (game.getSelectedTerritory2() != null){
                        if (game.getSelectedTerritory1() != null){
                            if (terr.player.equals(current_player)){
                                if (game.getSelectedTerritory1().terrAdjacent.contains(game.getSelectedTerritory2().name)){
                                    if (game.getSelectedTerritory1().getUnitNumberOfType(game.getSelectedUnitType()) > 1){
                                        Troop unitToMov = terr.getUnitByType(game.getSelectedUnitType());
                                        game.getSelectedTerritory2().getTroopList().add(unitToMov);
                                        game.getSelectedTerritory1().getTroopList().remove(unitToMov);
                                        update_Territory_Labels();
                                        update_Counters(terr);
                                        game.setSelectedTerritory1(null);
                                        game.setSelectedTerritory2(null);
                                    }
                                }
                                else
                                    System.out.println("Terr is not adjacent");
                            }
                        }
                    }
                    break;
                default:
                    System.out.println("Error in game state");
            }

        }
    }

    @FXML
    private void onNextTurn(ActionEvent event){


        game.setSelectedTerritory1(null);
        game.setSelectedTerritory2(null);

        if (players.size() > current_player.getId() + 1){
            current_player = players.get(current_player.getId() + 1);
        }
        else
            current_player = players.get(0);

        System.out.println("Current player is : " + current_player.getName() );
        game.getReinforcement(current_player);


        tGroup.selectToggle(btn_renfort);
        btn_renfort.setDisable(false);
        btn_attack.setDisable(true);
        btn_deplacement.setDisable(true);
        btn_renfort.setSelected(true);


        lb_NamePlayer.setText(current_player.getName());
        lb_NamePlayer.setTextFill(javafx.scene.paint.Color.rgb(current_player.getColor().getRed(), current_player.getColor().getGreen(), current_player.getColor().getBlue(), current_player.getColor().getAlpha() / 255.0));
        lb_nb_unit.setText("" +current_player.getTroopsToDistribute());
        lb_nb_cannons.setText("0");
        lb_nb_soldiers.setText("0");
        lb_nb_horseRiders.setText("0");
        lb_nb_Planes.setText("0");
        lb_nb_Tanks.setText("0");
    }

    private void update_Map(Territory terr){
        imageView.setImage(SwingFXUtils.toFXImage(ImageProcessor.colorTerritory(
                SwingFXUtils.fromFXImage(imageView.getImage(), null),
                terr,
                terr.player.getColor()), null) ); //TODO Change to match new player color
                List<Territory> aTer = game.getTerritoryList();
                Player ifWinner = aTer.get(0).getPlayer();
                int counter  = 0;
                for(Territory ter : aTer)
                {
                    if(ifWinner.getName() == ter.getPlayer().getName()){
                        counter++;
                    }
                }
                if(counter == 42){
                    System.out.println(current_player.getName() + " has won the game!!");
                    lb_NamePlayer.setText(current_player.getName() + " HAS WON THE GAME!!");
                }


    }

    private void setSelectedTerritory(Territory terr){
        if (game.getSelectedTerritory1() == null)
            game.setSelectedTerritory1(terr);
        else if (game.getState() == GameStage.REINFORCEMENT)
            game.setSelectedTerritory2(null);
        else if (terr.equals(game.getSelectedTerritory1())){
            if (game.getState() == GameStage.REINFORCEMENT)
                game.setSelectedTerritory2(null);
        }
        else if (game.getSelectedTerritory2() == null && !terr.equals(game.getSelectedTerritory1()))
            game.setSelectedTerritory2(terr);
        else if (!terr.equals(game.getSelectedTerritory1()) && !terr.equals(game.getSelectedTerritory2())){
            game.setSelectedTerritory1(terr);
            game.setSelectedTerritory2(null);
        }

        if (game.getSelectedTerritory1() != null)
            System.out.println("Selected Territory 1 :" + game.getSelectedTerritory1().name);
        if (game.getSelectedTerritory2() != null)
            System.out.println("Selected Territory 2 :" + game.getSelectedTerritory2().name);
    }

    private void update_Counters(Territory terr ){
        lb_nb_unit.setText(""+current_player.getTroopsToDistribute());
        lb_nb_soldiers.setText(""+terr.getUnitNumberOfType(TroopType.SOLDIER));
        lb_nb_cannons.setText(""+terr.getUnitNumberOfType(TroopType.CANNON));
        lb_nb_horseRiders.setText(""+terr.getUnitNumberOfType(TroopType.HORSE_RIDER));
    }
    private void update_Territory_Labels(){
        for (Node node : GameAnchor.getChildren()){
            if (node instanceof Label){
                String terr_name = ((Label)node).getId().replace("lb_", "");
                for (Territory terr : game.getTerritoryList()) {
                    if (terr.name.equals(terr_name)) {
                        ((Label)node).setText("" + terr.getTroopList().size());
                    }
                }
            }
        }
    }
    @FXML
    public void onReturnMainMenuButton (ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/view/MainMenuView.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();
            stage.setTitle("Main Menu");
            stage.setScene(scene);
            stage.show();
            Stage stg2 = (Stage) returnMainMenuButton.getScene().getWindow();
            stg2.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void onExitButton (ActionEvent event) {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
    }
    @FXML
    public void onAdjustButton(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/view/AdjustSettingsMenuView.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();
            stage.setTitle("Adjust Settings Menu");
            stage.setScene(scene);
            stage.show();
            Stage stg2 = (Stage) adjustButton.getScene().getWindow();
            stg2.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void onHowToPlayButton(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/view/HowToPlayView.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();
            stage.setTitle("Adjust Settings Menu");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}