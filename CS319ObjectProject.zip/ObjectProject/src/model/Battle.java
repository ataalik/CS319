/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 *
 * @author golfier
 */
public class Battle {

    private static Battle instance = null;

    public static Battle getInstance() {
        if(instance == null) {
            instance = new Battle();
        }
        return instance;
    }


    protected Battle () {

    }

    public void attackBetweenTerritory (Territory territoryA, Territory territoryB) {
        Player attackeur = territoryA.player;
        Player defenseur = territoryB.player;

        List<Troop> unitAttackeur = territoryA.getTroopList();
        List<Troop> unitDefenseur = territoryB.getTroopList();

        List<Troop> unitStayAttack = territoryA.getTroopList();
        List<Troop> unitStayDefense = territoryB.getTroopList();

        if (unitAttackeur.isEmpty() || unitDefenseur.isEmpty()) {
            System.out.println("The attacker or defender has no more units ...");
            return;
        }
        if (unitAttackeur.size() < 3){
            System.out.println("The attacker does not have enough units ...");
            return;
        }

        if (territoryA.equals(territoryB)){
            System.out.println("Player can not attack themselves");
            return;
        }

        if(!territoryA.terrAdjacent.contains(territoryB.name)){
            System.out.println("Player can not attack non-adjacent territory");
            return;
        }

        System.out.println("Attaque de :" + territoryA.name + " vers : " + territoryB.name);
        // Attacker attacks with up to 3 units at a time. He must always
        // stay at least 1 unit in the territory of departure that does not participate in
        // fight.
        int maxUnittoAttack = 3;
        int minToStay = 1;



        Collections.sort(unitAttackeur, new Comparator<Troop>() {
            @Override
            public int compare(Troop lhs, Troop rhs) {
                if (lhs.getPriorityAttack() < rhs.getPriorityAttack()) {
                    return -1;
                }
                else if (lhs.getPriorityAttack() > rhs.getPriorityAttack()) {
                    return 1;
                }
                else {
                    return 0;
                }
            }
        });

        List<Troop> unitForTheAttack = new ArrayList<Troop>();

        int size_max = unitAttackeur.size() - minToStay;

        while(size_max >= maxUnittoAttack) {
            size_max--;
        }

        for (int i = 0; i<size_max; i++) {
            unitForTheAttack.add(unitAttackeur.get(i));
            unitStayAttack.remove(unitAttackeur.get(i));

        }


        TerritoryFunctions.displayListUnit(unitForTheAttack);

        // The defender defends with a maximum of 2 units that are selected according to
        // their level of defensive priority: the soldiers defend first, then the
        // cannons, then the riders.


        int maxUnittoDefend = 2;

        //TerritoryAssets.displayListUnit(unitDefenseur);

        Collections.sort(unitDefenseur, new Comparator<Troop>() {
            @Override
            public int compare(Troop lhs, Troop rhs) {
                if (lhs.getPriorityAttack() < rhs.getPriorityAttack()) {
                    return 1;
                }
                else if (lhs.getPriorityAttack() > rhs.getPriorityAttack()) {
                    return -1;
                }
                else {
                    return 0;
                }
            }
        });

        List<Troop> unitForDefend = new ArrayList<Troop>();

        size_max = unitDefenseur.size();

        if(size_max > maxUnittoDefend) {
            size_max = maxUnittoDefend;
        }

        for (int j = 0; j<size_max; j++) {
            unitForDefend.add(unitDefenseur.get(j));
        }

        //TerritoryAssets.displayListUnit(unitForDefend);


        // A random number is generated for each unit according to the indi-
        // in the power column of Table 4.
        // The highest scores are compared for each side: higher
        // VS attacker higher defender, and 2nd higher vs. 2nd higher
        // if there are 2 units in defense. If multiple units have the same score in
        // a camp and only in this case: it is the lowest priority
        // (see Table 4) which is a priority for the highest comparison. We
        // note that priority in defense and attack are not the same!

        boolean attackeurWin = false;
        boolean conquisTerritoire = false;

        int length_def =  unitForDefend.size();
        int length_attack =  unitForTheAttack.size();
        int length_remenber = Math.min(length_attack,length_def);

        List<Troop> copyUnitForAttack = unitForTheAttack;
        List<Troop> copyUnitForDefense = unitForDefend;

        System.out.println(length_attack+ "  " +length_def+ "  " +length_remenber);

        for (int k=0; k<length_remenber; k++) {
            Troop unitNextAttack = copyUnitForAttack.iterator().next();
            Troop unitNextDefenseuh = copyUnitForDefense.iterator().next();
            //System.out.println("Unit to defend : " + unitNextDefense);
            //System.out.println("Unit to attack : " + unitNextAttack);

            /*
             * HERE you had done a function which was in duplicate, You would generate a new random number for the force then
             * that the force is random at the creation of the unit
             */

            int unitAtt = unitNextAttack.getStrength();
            int unitDef = unitNextDefenseuh.getStrength();
            //int unitAtt = unitNextAttack.getStrength();
            //int unitDef = unitNextDefenseuh.getStrength();4

            // For each comparison, the unit with the highest score destroyed
            // the one with the lowest score. Equality bene fi ts the defender.

            if (unitAtt > unitDef) {
                System.out.println(unitAtt + " > " + unitDef + " => Unit Attack win");
                if (unitForDefend.isEmpty()) {
                    System.out.println("The defender lost all their units");
                    attackeurWin = true;
                    conquisTerritoire = true;
                    break;
                } else {
                    System.out.println("Remove unit def, length : " + unitForDefend.size() +  " and : "+unitStayDefense.size());
                    if(unitForDefend.size() <= 1) {
                        attackeurWin = true;
                    }
                    if (unitForDefend.size() <= 1 && unitStayDefense.size() <= 1) {
                        System.out.println("Conquered territory");
                        conquisTerritoire = true;
                    }
                    unitForDefend.remove(unitNextDefenseuh);
                    unitStayDefense.remove(unitNextDefenseuh);
                }
            } else  {//if (unitAtt < unitDef) or if (unitAtt == unitDef)
                System.out.println(unitAtt + " < ou == " + unitDef + " => Unit Def win");
                if (unitForTheAttack.isEmpty()) {
                    System.out.println("The attacker lost all their units");
                    break;
                } else {
                    System.out.println("Remove unit attack"+ unitForTheAttack.size());
                    unitForTheAttack.remove(unitNextAttack);
                }

            }
        }


        //System.out.println("Unit after  bataille :");
        //TerritoryAssets.displayListUnit(unitForTheAttack);
        //TerritoryAssets.displayListUnit(unitForDefend);

        List<Troop> unitAfterAttack = new ArrayList<Troop>();
        List<Troop> unitAfterDefend = new ArrayList<Troop>();

        unitAfterAttack.addAll(unitForTheAttack);
        unitAfterDefend.addAll(unitForDefend);


        //System.out.println("List Unit after  bataille :");
        //TerritoryAssets.displayListUnit(unitAfterAttack);
        //TerritoryAssets.displayListUnit(unitAfterDefend);

        if (attackeurWin) {
            // He will have a 50% chance to have 1 extra reinforcement at his next
            // turn by captured territory.
            Random ran = new Random();
            int random = ran.nextInt(2);
            if (random == 0) {
                int rand2 =ran.nextInt(3);
                if (rand2 == 0) {
                    Troop unitRandom = new Troop(TroopType.SOLDIER);
                    System.out.println("The player has gained additional reinforcement of type:"+ TroopType.SOLDIER);
                    unitAfterAttack.add(unitRandom);
                } else if (rand2 == 1) {
                    Troop unitRandom = new Troop(TroopType.HORSE_RIDER);
                    System.out.println("The player has gained additional reinforcement of type:"+ TroopType.HORSE_RIDER);
                    unitAfterAttack.add(unitRandom);
                } else {
                    Troop unitRandom = new Troop(TroopType.CANNON);
                    System.out.println("The player has gained additional reinforcement of type:"+ TroopType.CANNON);
                    unitAfterAttack.add(unitRandom);
                }

            }
            // In case of capture of a territory, the attacker places there all units having
            // participated and survived the attack.

            territoryA.setBattleTerritory(attackeur, unitStayAttack);
            if (conquisTerritoire) {
                System.out.println("The Attacker won!");
                territoryB.setBattleTerritory(attackeur, unitAfterAttack);
            } else {
                territoryB.setBattleTerritory(defenseur, territoryB.getTroopList());
            }

        } else {
            territoryA.setBattleTerritory(attackeur, unitStayAttack);
            territoryB.setBattleTerritory(defenseur, territoryB.getTroopList());
        }

    }
}