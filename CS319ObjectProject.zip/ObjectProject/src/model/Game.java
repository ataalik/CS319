/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author golfier
 */
public class Game {

    private List<Player> list_player;
    private List<Color> maListeDeColor;
    private List<Pixel> maListeDePixel;
    private List<Territory> maListeDeTerritoire;

    private boolean finished;
    private boolean isFirstTour;
    private int num_tours;
    private GameStage state;

    private Territory selectedTerritory1;
    private Territory selectedTerritory2;

    private TroopType selectedUnitType;

    private static Game instance = null;
    private Battle bataille;


    public static Game getInstance() {
        if(instance == null) {
            instance = new Game();
        }
        return instance;
    }


    protected Game () {
        list_player = new ArrayList<Player>();
        maListeDeColor = new ArrayList<Color>();
        maListeDePixel = new ArrayList<Pixel>();
        maListeDeTerritoire = new ArrayList<Territory>();
        finished = false;
        num_tours = 0;
        selectedTerritory1 = null;
        selectedTerritory2 = null;
        setSelectedUnitType(TroopType.SOLDIER);
        isFirstTour = true;
    }

    /**
     * @return the list_player
     */
    public List<Player> getPlayerList() {
        return list_player;
    }

    /**
     * @param list_player the list_player to set
     */
    public void setPlayerList(List<Player> list_player) {
        this.list_player = list_player;
    }

    /**
     * @return the maListeDeColor
     */
    public List<Color> getColorList() {
        return maListeDeColor;
    }

    /**
     * @param maListeDeColor the maListeDeColor to set
     */
    public void setColorList(List<Color> maListeDeColor) {
        this.maListeDeColor = maListeDeColor;
    }

    /**
     * @return the maListeDePixel
     */
    public List<Pixel> getPixelList() {
        return maListeDePixel;
    }

    /**
     * @param maListeDePixel the maListeDePixel to set
     */
    public void setPixelList(List<Pixel> maListeDePixel) {
        this.maListeDePixel = maListeDePixel;
    }

    /**
     * @return the finished
     */
    public boolean isFinished() {
        boolean finished = false;
        int length = list_player.size();
        int occurence = 0;
        for (Player p : list_player) {
            if(!p.isFinished()) {
                occurence++;
            }
        }
        int nb_joueur_restant = length - occurence ;
        if (nb_joueur_restant <= 1) {
            finished = true;
        }
        return finished;
    }

    /**
     * @param finished the finished to set
     */
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public Territory tellTerritory(int x, int y) {
        for (Iterator<Territory> it = getTerritoryList().iterator(); it.hasNext();) {
            Territory territory = it.next();
            List<Pixel> listPixel = territory.getListPixel();
            for (Pixel p : listPixel) {
                if (p.y == y && p.x == x) {
                    return territory;
                }

            }
        }
        return null;

    }

    /**
     * @return the maListeDeTerritoire
     */
    public List<Territory> getTerritoryList() {
        return maListeDeTerritoire;
    }

    /**
     * @param maListeDeTerritoire the maListeDeTerritoire to set
     */
    public void setTerritoryList(List<Territory> maListeDeTerritoire) {
        this.maListeDeTerritoire = maListeDeTerritoire;
    }

    /**
     * @return the num_tours
     */
    public int getNumTours() {
        return num_tours;
    }

    /**
     * @param num_tours the num_tours to set
     */
    public void setTours(int num_tours) {
        this.num_tours = num_tours;
    }


    public List<Color> getListColor (int nb_joueurs) {
        List<Color> maListe = new ArrayList<Color>();
        List<Color> final_list = new ArrayList<Color>();
        Color color1 = new Color (47,79,79); //darkslategrey
        Color color2 = new Color (128,0,128); //purple
        Color color3 = new Color (128,128,0); //olive
        Color color4 = new Color (0,100,0); //dark green
        Color color5 = new Color (128,0,0); //maroon
        Color color6 = new Color (0,0,128); //navy
        Random rand = new Random();

        maListe.add(color1);
        maListe.add(color2);
        maListe.add(color3);
        maListe.add(color4);
        maListe.add(color5);
        maListe.add(color6);

        for(int i=0; i<nb_joueurs; i++) {
            int randomIndex = rand.nextInt(maListe.size());
            final_list.add(maListe.get(randomIndex));
            maListe.remove(randomIndex);
        }

        System.out.println("List of Color for those players : "+final_list);


        return final_list;
    }

    public void initTerritory(){

        int nbUnitTodispatch = 0;
        switch(list_player.size())
        {
            case 2:
                nbUnitTodispatch = 40;
                break;
            case 3:
                nbUnitTodispatch = 35;
                break;
            case 4:
                nbUnitTodispatch = 30;
                break;
            case 5:
                nbUnitTodispatch = 25;
                break;
            case 6:
                nbUnitTodispatch = 20;
                break;
        }

        for (Player player : list_player) {
            player.setTroopsToDistribute(nbUnitTodispatch);
        }
        for (Territory terr: maListeDeTerritoire){
            Troop unitToDispatch = new Troop(TroopType.SOLDIER);
            terr.getTroopList().add(unitToDispatch);
            terr.player.setTroopsToDistribute(terr.player.getTroopsToDistribute() - unitToDispatch.getCost() );
        }

    }


    public GameStage getState() {
        return state;
    }


    public void setState(GameStage state) {
        this.state = state;
    }

    /**
     * @return the selectedTerritory1
     */
    public Territory getSelectedTerritory1() {
        return selectedTerritory1;
    }

    /**
     * @return the selectedTerritory2
     */
    public Territory getSelectedTerritory2() {
        return selectedTerritory2;
    }

    public Player getPlayerWithName (String name) {
        List<Player> list = getPlayerList();
        for (Player p : list) {
            if (p.getName().equals(name))
                return p;
        }
        return null;
    }

    public void getReinforcement(Player player){
        int nb_terr_controlled = (int) getTerritoryList().stream().filter(p -> p.player.equals(player)).count();
        int nb_region_controlled = TerritoryFunctions.countRegions((List<Territory>) getTerritoryList().stream().filter(p -> p.player.equals(player)).collect(Collectors.toList()) );
        if (player.getTroopsToDistribute() == 0)
            player.setTroopsToDistribute((int) Math.floorDiv(nb_terr_controlled,3) + (int) Math.floorDiv(nb_region_controlled, 3));
    }
    /**
     * @param selectedTerritory1 the selectedTerritory1 to set
     */
    public void setSelectedTerritory1(Territory selectedTerritory1) {
        this.selectedTerritory1 = selectedTerritory1;
    }


    /**
     * @param selectedTerritory2 the selectedTerritory2 to set
     */
    public void setSelectedTerritory2(Territory selectedTerritory2) {
        this.selectedTerritory2 = selectedTerritory2;
    }


    public TroopType getSelectedUnitType() {
        return selectedUnitType;
    }


    public void setSelectedUnitType(TroopType selectedUnitType) {
        this.selectedUnitType = selectedUnitType;
    }



}