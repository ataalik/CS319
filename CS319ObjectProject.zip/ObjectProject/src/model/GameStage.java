package model;

public enum GameStage {
    ATTACK,
    REINFORCEMENT,
    DEPLACEMENT
}