package model;

import java.util.Random;

public class Troop{

    private TroopType type;
    private int Strength;
    private int priorityAttack;
    private int priorityDefence;
    private int movementPerTour;
    private int cost;

    public Troop(){}

    public Troop(TroopType unitType){
        if (unitType == TroopType.SOLDIER){
            this.type = TroopType.SOLDIER;
            this.Strength = giveRandomNumber(1,6);
            this.cost = 1;
            this.priorityAttack = 2;
            this.priorityDefence = 1;
            this.movementPerTour = 2;
        }
        else if (unitType == TroopType.HORSE_RIDER){
            this.type = TroopType.HORSE_RIDER;
            this.Strength = giveRandomNumber(2,7);
            this.cost = 3;
            this.priorityAttack = 1;
            this.priorityDefence = 3;
            this.movementPerTour = 3;

        }
        else if (unitType == TroopType.CANNON){
            this.type = TroopType.CANNON;
            this.Strength = giveRandomNumber(4,9);
            this.cost = 7;
            this.priorityAttack = 3;
            this.priorityDefence = 2;
            this.movementPerTour = 1;
        }
        else if (unitType == TroopType.TANK){
            this.type = TroopType.TANK;
            this.Strength = giveRandomNumber(4,9);
            this.cost = 9;
            this.priorityAttack = 4;
            this.priorityDefence = 4;
            this.movementPerTour = 1;
        }
        else if (unitType == TroopType.PLANE){
            this.type = TroopType.PLANE;
            this.Strength = giveRandomNumber(4,9);
            this.cost = 12;
            this.priorityAttack = 5;
            this.priorityDefence = 5;
            this.movementPerTour = 1;
        }
    }

    public Troop(TroopType unitType, int Strength, int cost, int priorityAttack, int priorityDefence, int movementpertour){
        this.type = unitType;
        this.Strength = Strength;
        this.cost = cost;
        this.priorityAttack = priorityAttack;
        this.priorityDefence = priorityDefence;
        this.movementPerTour = movementpertour;
    }

    public int giveRandomNumber(int leftLimit, int rightLimit ) {
        Random rdm = new Random();
        return rdm.nextInt((rightLimit - leftLimit) + 1) + leftLimit;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Troop))
            return false;
        Troop other = (Troop) obj;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        return true;
    }

    /**
     * @return the type
     */
    public TroopType getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(TroopType type) {
        this.type = type;
    }

    /**
     * @return the strength
     */
    public int getStrength() {
        return Strength;
    }

    public int getStrengthType(TroopType unitType) {
        if (unitType == TroopType.SOLDIER){
            return giveRandomNumber(1,6);
        }
        if (unitType == TroopType.HORSE_RIDER){
            return giveRandomNumber(2,7);
        }
        if (unitType == TroopType.CANNON){
            return giveRandomNumber(4,9);
        }
        if (unitType == TroopType.TANK){
            return giveRandomNumber(5,10);
        }
        if (unitType == TroopType.PLANE){
            return giveRandomNumber(6,11);
        }
        return 0;
    }

    /**
     * @param strength the strength to set
     */
    public void setStrength(int strength) {
        Strength = strength;
    }

    /**
     * @return the priorityAttack
     */
    public int getPriorityAttack() {
        return priorityAttack;
    }

    /**
     * @param priorityAttack the priorityAttack to set
     */
    public void setPriorityAttack(int priorityAttack) {
        this.priorityAttack = priorityAttack;
    }

    /**
     * @return the priorityDefence
     */
    public int getPriorityDefence() {
        return priorityDefence;
    }

    /**
     * @param priorityDefence the priorityDefence to set
     */
    public void setPriorityDefence(int priorityDefence) {
        this.priorityDefence = priorityDefence;
    }

    /**
     * @return the movementPerTour
     */
    public int getMovementPerTour() {
        return movementPerTour;
    }

    /**
     * @param movementPerTour the movementPerTour to set
     */
    public void setMovementPerTour(int movementPerTour) {
        this.movementPerTour = movementPerTour;
    }

    /**
     * @return the cost
     */
    public int getCost() {
        return cost;
    }

    /**
     * @param cost the cost to set
     */
    public void setCost(int cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        String toDisplay = "Type :" + this.getType().toString() + "\n";
        toDisplay += "Strength :" + this.getStrength() + "\n";
        toDisplay += "Priority Attack :" + this.getPriorityAttack() + "\n";
        toDisplay += "Priority Defence :" + this.getPriorityDefence() + "\n";
        toDisplay += "Movement Per Tour :" + this.getMovementPerTour() + "\n";
        return toDisplay;
    }
}