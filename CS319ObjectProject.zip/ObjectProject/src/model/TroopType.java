package model;

public enum TroopType {
    SOLDIER,
    HORSE_RIDER,
    CANNON,
    TANK,
    PLANE;
}